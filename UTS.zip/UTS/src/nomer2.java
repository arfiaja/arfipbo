import java.util.Scanner;

public class nomer2 {

    public static void main(String[] args)
    {
        Scanner masuk = new Scanner(System.in);
        float berat, tinggi, bmi, meter;

        System.out.println("MENENTUKAN BERAT BADAN IDEAL MELALUI FORMULA BMI");
        System.out.println("............................................");
        System.out.print ("Berat Badan(kg): ");
        berat = masuk.nextFloat();
        System.out.print ("Tinggi Badan(cm): ");
        tinggi = masuk.nextFloat();
        meter=tinggi/100;
        bmi=(berat/(meter*meter));

        System.out.println("............................................");
        System.out.print("BMI : "+bmi+" ");

        if (bmi<18.5){
            System.out.println("(IDEAL)");
        }else if (bmi<22.9){
            System.out.println("(Overweight)");

        }

    }
}

