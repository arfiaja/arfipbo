public class nomer4 {

public static void main(String[]arg){
    int i=1, jum=0;
    do{jum=jum+i;
        System.out.print(i+"+");i++;
    }while(i<=10);
    System.out.println();
    System.out.println("Penjumlahan 10 Bilangan = "+jum);
}
}